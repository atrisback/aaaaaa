const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let particles = [];

// Função para criar partículas
class Particle {
  constructor(x, y, color) {
    this.x = x;
    this.y = y;
    this.size = Math.random() * 2 + 1;
    this.color = color;
    this.speedX = Math.random() * 2 - 1;
    this.speedY = Math.random() * 2 - 1;
  }

  update() {
    this.x += this.speedX;
    this.y += this.speedY;
    if (this.size > 0.2) this.size -= 0.02;
  }

  draw() {
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fill();
  }
}

// Desenhar coração com fórmula matemática
function drawHeart() {
  let t = 0;
  const heart = setInterval(() => {
    t += 0.1;
    let x = 16 * Math.sin(t) ** 3;
    let y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));

    particles.push(new Particle(
      canvas.width/2 + x * 20,
      canvas.height/2 + y * 20,
      "rgba(255,0,150,0.8)"
    ));

    if (t > Math.PI * 2) clearInterval(heart);
  }, 30);
}

// Escrever texto "Te Amo"
function drawText() {
  ctx.font = "50px Arial";
  ctx.fillStyle = "white";
  ctx.textAlign = "center";
  ctx.fillText("Te Amo", canvas.width/2, canvas.height/1.2);
}

// Animação
function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawText();

  particles.forEach((p, i) => {
    p.update();
    p.draw();
    if (p.size <= 0.2) particles.splice(i, 1);
  });

  requestAnimationFrame(animate);
}

drawHeart();
animate();